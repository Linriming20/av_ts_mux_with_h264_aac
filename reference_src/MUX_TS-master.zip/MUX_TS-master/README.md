# MUX_TS
h264+aac=ts

有关说明，请移步：https://my.oschina.net/u/2430809/blog/727904.时间有限，见谅。
